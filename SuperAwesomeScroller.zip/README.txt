Super Awesome Scroller :D

Controls:

L-ctrl -> Turbo
Space  -> Shoot

Extra:

I added the turbo, and collision with
the screen borders